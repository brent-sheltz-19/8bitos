// Wokwi Custom Chip - For docs and examples see:
// https://docs.wokwi.com/chips-api/getting-started
//
// SPDX-License-Identifier: MIT
// Copyright 2023 Brent Sheltz

#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>
#define size =4,096;
#define half = 2048;

typedef struct cells
{
  int value;
  struct cells* next;
 
}cells;
typedef struct
{
 cells list;
}linkedlist;
typedef struct {
  // TODO: Put your chip variables here
  linkedlist head;
  int count;
  cells* writeptr,readptr,
} chip_state_t;
void add(struct cells* list, int value)
{
  cells* newnode = ( cells*)malloc(sizeof(cells));
  cells* curr = list;
  if()
  {
    
  }
  while( curr->next != NULL)
  {
    curr = curr->next;
  }
  curr->next = newnode;


}
void read
void chip_init() {
  chip_state_t *chip = malloc(sizeof(chip_state_t));
  
  // TODO: Initialize the chip, set up IO pins, create timers, etc.

  printf("Hello from custom chip!\n");
}
