// Wokwi Custom Chip - For docs and examples see:
// https://docs.wokwi.com/chips-api/getting-started
//
// SPDX-License-Identifier: MIT
// Copyright 2023 

#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct {
  // TODO: Put your chip variables here
  char *hello;
  pin_t A0,A1,A2,A3,A4,A5,A6,A7,A8;
  uint32_t address;
  
} chip_state_t;

void chip_init() {
  chip_state_t *chip = malloc(sizeof(chip_state_t));
  printf("%lu \n",sizeof(chip_state_t));
  printf("%lu \n",sizeof(uint32_t));
  chip->A0 = pin_init("a0", INPUT);

  chip->hello=  "hello world";
  // TODO: Initialize the chip, set up IO pins, create timers, etc.

  printf("Hello from custom chip!\n");
}
void pin_mode(pin_t pin, uint32_t mode)
{}
void read()
{
  


}